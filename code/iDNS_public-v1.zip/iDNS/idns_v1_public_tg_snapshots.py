#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iDNS Taylor-Green Vortex Solver with Snapshots — Public Release
----------------------------------------------------------------
Author: Jeffrey Camlin
© 2025 Red Dawn Academic Press & AI Lab, Milwaukee WI
License: CC BY-NC 4.0 (Attribution-NonCommercial)
https://creativecommons.org/licenses/by-nc/4.0/

This solver includes 3D velocity field snapshots at t = 3.0, 4.0, 4.5, 5.0
for visualization and validation of the turbulent cascade.

Provided for scientific and academic reproducibility of the Taylor-Green
Re=10^5 flow benchmarks reported in:

"iDNS: Intelligent Adaptive Policy for Turbulence Simulation via Temporal Lifting"

Repository: https://github.com/reddawnacademicpress/iDNS
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import time
import csv
import os
from datetime import datetime
from dataclasses import dataclass


@dataclass
class Config:
    """Simulation parameters for 3D Taylor-Green vortex."""
    N: int = 128                    # Grid resolution (N^3 modes)
    L: float = 2 * np.pi            # Domain size
    Re: float = 100_000.0           # Reynolds number
    T_final: float = 5.0            # Integration time
    dt_base: float = 1e-4           # Base timestep
    
    # Sigmoid temporal-lift parameters
    lift_A: float = 1.0             # Amplitude
    lift_k: float = 12.0            # Steepness
    lift_center: float = 0.6        # Activation threshold
    
    # Output control
    out_dir: str = "results"
    print_every: int = 100
    
    # Snapshot times for 3D field output
    snapshot_times: tuple = (3.0, 4.0, 4.5, 5.0)


class SpectralNS3D:
    """3D Fourier-Galerkin Navier-Stokes solver on periodic domain."""
    
    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.nu = 1.0 / cfg.Re
        
        # Wavenumber grid
        dx = cfg.L / cfg.N
        k = 2 * np.pi * np.fft.fftfreq(cfg.N, d=dx)
        self.KX, self.KY, self.KZ = np.meshgrid(k, k, k, indexing='ij')
        self.K2 = self.KX**2 + self.KY**2 + self.KZ**2
        self.K2[0, 0, 0] = 1.0  # Avoid division by zero
        self.Kmag = np.sqrt(self.K2)
        
        # 2/3 dealiasing mask
        kcut = (cfg.N / 3.0) * (2 * np.pi / cfg.L)
        self.DEALIAS = (self.Kmag <= kcut)
        
        # Physical grid
        x = np.linspace(0, cfg.L, cfg.N, endpoint=False)
        self.X, self.Y, self.Z = np.meshgrid(x, x, x, indexing='ij')
        
        print(f"  Grid: {cfg.N}^3 = {cfg.N**3:,} points")
        print(f"  Memory: ~{3 * cfg.N**3 * 16 / 1e9:.2f} GB")
    
    def project_div_free(self, uh, vh, wh):
        """Leray projection to divergence-free subspace."""
        KX, KY, KZ, K2 = self.KX, self.KY, self.KZ, self.K2
        Pxx = 1 - KX * KX / K2
        Pyy = 1 - KY * KY / K2
        Pzz = 1 - KZ * KZ / K2
        Pxy = -KX * KY / K2
        Pxz = -KX * KZ / K2
        Pyz = -KY * KZ / K2
        
        uh2 = Pxx * uh + Pxy * vh + Pxz * wh
        vh2 = Pxy * uh + Pyy * vh + Pyz * wh
        wh2 = Pxz * uh + Pyz * vh + Pzz * wh
        
        uh2[0, 0, 0] = vh2[0, 0, 0] = wh2[0, 0, 0] = 0
        return uh2, vh2, wh2
    
    def vorticity(self, uh, vh, wh):
        """Compute vorticity in Fourier space."""
        return (1j * self.KY * wh - 1j * self.KZ * vh,
                1j * self.KZ * uh - 1j * self.KX * wh,
                1j * self.KX * vh - 1j * self.KY * uh)
    
    def nonlinear(self, uh, vh, wh):
        """Compute nonlinear advection term pseudospectrally."""
        u = np.fft.ifftn(uh).real
        v = np.fft.ifftn(vh).real
        w = np.fft.ifftn(wh).real
        
        dudx = np.fft.ifftn(1j * self.KX * uh).real
        dudy = np.fft.ifftn(1j * self.KY * uh).real
        dudz = np.fft.ifftn(1j * self.KZ * uh).real
        dvdx = np.fft.ifftn(1j * self.KX * vh).real
        dvdy = np.fft.ifftn(1j * self.KY * vh).real
        dvdz = np.fft.ifftn(1j * self.KZ * vh).real
        dwdx = np.fft.ifftn(1j * self.KX * wh).real
        dwdy = np.fft.ifftn(1j * self.KY * wh).real
        dwdz = np.fft.ifftn(1j * self.KZ * wh).real
        
        NLx = -(u * dudx + v * dudy + w * dudz)
        NLy = -(u * dvdx + v * dvdy + w * dvdz)
        NLz = -(u * dwdx + v * dwdy + w * dwdz)
        
        NLx_h = np.fft.fftn(NLx) * self.DEALIAS
        NLy_h = np.fft.fftn(NLy) * self.DEALIAS
        NLz_h = np.fft.fftn(NLz) * self.DEALIAS
        
        return self.project_div_free(NLx_h, NLy_h, NLz_h)
    
    def rhs(self, uh, vh, wh):
        """Right-hand side: advection + viscous diffusion."""
        NLx, NLy, NLz = self.nonlinear(uh, vh, wh)
        return (NLx - self.nu * self.K2 * uh,
                NLy - self.nu * self.K2 * vh,
                NLz - self.nu * self.K2 * wh)
    
    def rk4_step(self, uh, vh, wh, dt):
        """Classical 4th-order Runge-Kutta integration."""
        k1 = self.rhs(uh, vh, wh)
        k2 = self.rhs(uh + 0.5 * dt * k1[0],
                      vh + 0.5 * dt * k1[1],
                      wh + 0.5 * dt * k1[2])
        k3 = self.rhs(uh + 0.5 * dt * k2[0],
                      vh + 0.5 * dt * k2[1],
                      wh + 0.5 * dt * k2[2])
        k4 = self.rhs(uh + dt * k3[0],
                      vh + dt * k3[1],
                      wh + dt * k3[2])
        
        uh = uh + (dt / 6) * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])
        vh = vh + (dt / 6) * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])
        wh = wh + (dt / 6) * (k1[2] + 2 * k2[2] + 2 * k3[2] + k4[2])
        
        uh = uh * self.DEALIAS
        vh = vh * self.DEALIAS
        wh = wh * self.DEALIAS
        
        return self.project_div_free(uh, vh, wh)
    
    def energy(self, uh, vh, wh):
        """Kinetic energy: E = 0.5 * ||u||^2."""
        return 0.5 * (np.sum(np.abs(uh)**2) + 
                      np.sum(np.abs(vh)**2) + 
                      np.sum(np.abs(wh)**2)) / self.cfg.N**3
    
    def enstrophy(self, uh, vh, wh):
        """Enstrophy: Z = 0.5 * ||omega||^2."""
        wx, wy, wz = self.vorticity(uh, vh, wh)
        return 0.5 * (np.sum(np.abs(wx)**2) + 
                      np.sum(np.abs(wy)**2) + 
                      np.sum(np.abs(wz)**2)) / self.cfg.N**3
    
    def vorticity_max(self, uh, vh, wh):
        """Maximum vorticity magnitude."""
        wx, wy, wz = self.vorticity(uh, vh, wh)
        wx = np.fft.ifftn(wx).real
        wy = np.fft.ifftn(wy).real
        wz = np.fft.ifftn(wz).real
        return float(np.max(np.sqrt(wx**2 + wy**2 + wz**2)))
    
    def stiffness_indicator(self, uh, vh, wh):
        """Compute D_omega = ||grad(omega)||_2 / ||omega||_2."""
        wx, wy, wz = self.vorticity(uh, vh, wh)
        wx = np.fft.ifftn(wx).real
        wy = np.fft.ifftn(wy).real
        wz = np.fft.ifftn(wz).real
        
        omega_mag = np.sqrt(wx**2 + wy**2 + wz**2)
        omega_h = np.fft.fftn(omega_mag)
        
        gradx = np.fft.ifftn(1j * self.KX * omega_h).real
        grady = np.fft.ifftn(1j * self.KY * omega_h).real
        gradz = np.fft.ifftn(1j * self.KZ * omega_h).real
        
        grad_norm = np.sqrt(gradx**2 + grady**2 + gradz**2)
        return float(np.linalg.norm(grad_norm) / (np.linalg.norm(omega_mag) + 1e-12))


def sigmoid_phi(Dw, A=1.0, k=12.0, center=0.6):
    """Sigmoid temporal-lift controller: phi'(tau) = 1 + A / (1 + exp(-k*(Dw - center)))."""
    return 1.0 + A / (1.0 + np.exp(-k * (Dw - center)))


def init_taylor_green(solver):
    """Initialize Taylor-Green vortex: u = (sin x cos y cos z, -cos x sin y cos z, 0)."""
    X, Y, Z = solver.X, solver.Y, solver.Z
    u = np.sin(X) * np.cos(Y) * np.cos(Z)
    v = -np.cos(X) * np.sin(Y) * np.cos(Z)
    w = np.zeros_like(u)
    
    uh = np.fft.fftn(u) * solver.DEALIAS
    vh = np.fft.fftn(v) * solver.DEALIAS
    wh = np.fft.fftn(w) * solver.DEALIAS
    
    return solver.project_div_free(uh, vh, wh)


def run_simulation(cfg: Config):
    """Main simulation loop with temporal lifting and field snapshots."""
    print("\n" + "=" * 70)
    print("  iDNS Taylor-Green Vortex Solver (Snapshot Edition)")
    print("=" * 70)
    
    os.makedirs(cfg.out_dir, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = f"{cfg.out_dir}/TG_Re{int(cfg.Re)}_{stamp}.csv"
    png_path = f"{cfg.out_dir}/TG_Re{int(cfg.Re)}_{stamp}.png"
    
    wall_start = time.time()
    solver = SpectralNS3D(cfg)
    uh, vh, wh = init_taylor_green(solver)
    
    E0 = solver.energy(uh, vh, wh)
    Z0 = solver.enstrophy(uh, vh, wh)
    print(f"  E(0) = {E0:.6e}")
    print(f"  Z(0) = {Z0:.6e}")
    print(f"  Re = {cfg.Re:.0e}")
    print(f"  Snapshots at t = {cfg.snapshot_times}")
    print()
    
    t, step = 0.0, 0
    BKM = 0.0
    omega_prev = None
    
    # Storage for plotting
    times, wmaxs, phis, Es, Zs = [], [], [], [], []
    
    # Snapshot tracking
    snapshot_saved = {ts: False for ts in cfg.snapshot_times}
    
    # CSV output
    with open(csv_path, 'w', newline='') as csvf:
        writer = csv.writer(csvf)
        writer.writerow(['time', 'step', 'omega_max', 'phi_prime', 'energy', 'enstrophy', 'BKM'])
        
        print(f"{'t':>8} {'step':>7} {'omega_max':>10} {'phi':>8} {'E':>12} {'Z':>12}")
        print("-" * 65)
        
        while t < cfg.T_final:
            E = solver.energy(uh, vh, wh)
            Z = solver.enstrophy(uh, vh, wh)
            omega_max = solver.vorticity_max(uh, vh, wh)
            
            # Temporal lift controller
            Dw = solver.stiffness_indicator(uh, vh, wh)
            phi = sigmoid_phi(Dw, cfg.lift_A, cfg.lift_k, cfg.lift_center)
            dt = cfg.dt_base * phi
            
            # BKM integral (trapezoidal)
            if omega_prev is not None:
                BKM += 0.5 * (omega_max + omega_prev) * dt
            omega_prev = omega_max
            
            # RK4 step
            uh, vh, wh = solver.rk4_step(uh, vh, wh, dt)
            
            # Save 3D snapshots at specified times
            for ts in cfg.snapshot_times:
                if not snapshot_saved[ts] and abs(t - ts) < 2 * dt:
                    ux = np.fft.ifftn(uh).real
                    uy = np.fft.ifftn(vh).real
                    uz = np.fft.ifftn(wh).real
                    fname = f"{cfg.out_dir}/field_t{ts:.1f}.npz"
                    np.savez(fname, ux=ux, uy=uy, uz=uz, t=t,
                             energy=E, enstrophy=Z, omega_max=omega_max)
                    print(f"  [Snapshot] t={t:.4f} -> {fname}")
                    snapshot_saved[ts] = True
            
            # Output
            if step % cfg.print_every == 0:
                print(f"{t:8.3f} {step:7d} {omega_max:10.3f} {phi:8.4f} {E:12.5e} {Z:12.5e}")
                times.append(t)
                wmaxs.append(omega_max)
                phis.append(phi)
                Es.append(E)
                Zs.append(Z)
                writer.writerow([t, step, omega_max, phi, E, Z, BKM])
                csvf.flush()
            
            t += dt
            step += 1
    
    wall_time = time.time() - wall_start
    print()
    print(f"Completed: {step} steps in {wall_time/3600:.2f} hours")
    print(f"Final BKM integral: {BKM:.2f}")
    print(f"CSV saved: {csv_path}")
    
    # Plot results
    fig, axes = plt.subplots(3, 1, figsize=(12, 9), sharex=True)
    
    axes[0].plot(times, wmaxs, 'b-', lw=1.5)
    axes[0].set_ylabel(r'$\|\omega\|_\infty$')
    axes[0].set_title(f'Taylor-Green Vortex at Re = {cfg.Re:.0e}')
    axes[0].grid(True, alpha=0.3)
    
    axes[1].plot(times, phis, 'g-', lw=1.5)
    axes[1].set_ylabel(r"$\phi'(\tau)$")
    axes[1].grid(True, alpha=0.3)
    
    axes[2].plot(times, Es, 'b-', lw=1.5, label='Energy')
    axes[2].set_ylabel('Energy', color='b')
    ax2 = axes[2].twinx()
    ax2.plot(times, Zs, 'r-', lw=1.5, label='Enstrophy')
    ax2.set_ylabel('Enstrophy', color='r')
    axes[2].set_xlabel('Time t')
    axes[2].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(png_path, dpi=150)
    print(f"Plot saved: {png_path}")
    
    return {
        'steps': step,
        'wall_time': wall_time,
        'BKM': BKM,
        'final_energy': Es[-1] if Es else None,
        'final_enstrophy': Zs[-1] if Zs else None,
        'snapshots': list(snapshot_saved.keys())
    }


if __name__ == "__main__":
    cfg = Config()
    run_simulation(cfg)