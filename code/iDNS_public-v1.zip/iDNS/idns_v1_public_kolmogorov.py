#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
iDNS Minimal Kolmogorov Flow Solver — Public Release
----------------------------------------------------
Author: Jeffrey Camlin
© 2025 Red Dawn Academic Press & AI Lab, Milwaukee WI
License: CC BY-NC 4.0 (Attribution–NonCommercial)
https://creativecommons.org/licenses/by-nc/4.0/

This minimal solver is provided for scientific and academic
reproducibility of the Kolmogorov flow benchmarks reported in:

"iDNS: Intelligent Adaptive Policy for Turbulence Simulation via Temporal Lifting"
"""

import argparse, os, csv, time
import numpy as np
from numpy.fft import fft2, ifft2, fftfreq

# ============================================================
# CLI SETUP
# ============================================================
parser = argparse.ArgumentParser(description="iDNS v1 Public Kolmogorov Flow Solver")
parser.add_argument("--mode", choices=["conservative", "idns"], default="idns")
parser.add_argument("--Re", type=float, default=20000.0)
parser.add_argument("--t_end", type=float, default=100.0)
parser.add_argument("--seed", type=int, default=48)
parser.add_argument("--outdir", type=str, default="results")
args = parser.parse_args()

# ============================================================
# CONFIGURATION
# ============================================================
N = 256
L = 2 * np.pi
F = 2.5
kf = 8

mode = args.mode
Re = args.Re
seed = args.seed

outdir = os.path.join(args.outdir, "kolmogorov")
os.makedirs(outdir, exist_ok=True)

dt = 0.001 if mode == "conservative" else 0.006
nu = L / (kf * Re)
phi_prime = 1.0
print_interval = 100

# ============================================================
# HEADER
# ============================================================
outname = f"idns_public_N{N}_Re{int(Re)}.csv"
print("\n" + "="*70)
print(f" iDNS v1 Public | MODE={mode.upper()} | N={N} | Re={Re:.1e}")
print(f" dt={dt}   t_end={args.t_end}   nu={nu:.6e}")
print(f" Temporal lifting: {'ON' if mode=='idns' else 'OFF'}")
print(f" Output: {outname}")
print("="*70)

# ============================================================
# SPECTRAL SETUP
# ============================================================
k = fftfreq(N, d=L / N) * 2 * np.pi
kx, ky = np.meshgrid(k, k, indexing="ij")
k2 = kx**2 + ky**2
k2[0, 0] = 1.0

def project_uv_from_w(w_hat):
    psi_hat = -w_hat / k2
    u_hat = 1j * ky * psi_hat
    v_hat = -1j * kx * psi_hat
    return np.real(ifft2(u_hat)), np.real(ifft2(v_hat))

def rhs_hat(w_hat, nu, curlf_hat):
    w = np.real(ifft2(w_hat))
    wx, wy = np.gradient(w, axis=1), np.gradient(w, axis=0)
    u, v = project_uv_from_w(w_hat)
    adv = u * wx + v * wy
    return -fft2(adv) - nu * k2 * w_hat + curlf_hat

# ============================================================
# FORCING
# ============================================================
y = np.linspace(0, L, N, endpoint=False)
curlf = -F * kf * np.cos(kf * y)
curlf = np.tile(curlf[:, None], (1, N))
curlf_hat = fft2(curlf)

# ============================================================
# INITIAL CONDITIONS
# ============================================================
rng = np.random.default_rng(seed)
w0 = -kf * np.cos(kf * y)
w0 = np.tile(w0[:, None], (1, N))
w0 += 0.02 * kf * rng.standard_normal((N, N))

print(f"Initialization complete: perturbation amplitude={0.02*kf:.4f}, seed={seed}")

w_hat = fft2(w0)

# ============================================================
# MAIN LOOP
# ============================================================
start_time = time.time()
t = tau = 0.0
step = 0

rows = []

print("\nSimulation started...\n")

while t < args.t_end:
    step += 1

    # Temporal lifting controller
    if mode == "idns":
        w = np.real(ifft2(w_hat))
        w_inf = float(np.max(np.abs(w)))
        spec_amp = float(np.sqrt(np.sum(k2 * np.abs(w_hat)**2)))

        score = 0.6 * min(1.0, w_inf / 20.0) + 0.4 * min(1.0, spec_amp / 10.0)
        alpha, center, sigma_min = 4.5, 0.55, 0.03
        sigma = sigma_min + (1.0 - sigma_min) / (1.0 + np.exp(alpha * (score - center)))
        phi_prime = 1.0 / sigma

        if w_inf > 5000:
            phi_prime = min(30.0, 1.5 * phi_prime)

    else:
        phi_prime = 1.0

    # RK4 (lifted time)
    fac = 1.0 / max(1.0, phi_prime)
    k1 = fac * rhs_hat(w_hat, nu, curlf_hat)
    k2v = fac * rhs_hat(w_hat + 0.5*dt*k1, nu, curlf_hat)
    k3 = fac * rhs_hat(w_hat + 0.5*dt*k2v, nu, curlf_hat)
    k4 = fac * rhs_hat(w_hat + dt*k3, nu, curlf_hat)
    w_hat = w_hat + (dt/6.0)*(k1 + 2*k2v + 2*k3 + k4)

    # Diagnostics
    w = np.real(ifft2(w_hat))
    w_inf = float(np.max(np.abs(w)))
    u, v = project_uv_from_w(w_hat)
    E_phys = 0.5 * np.mean(u**2 + v**2)
    Z_phys = 0.5 * np.mean(w**2)

    rows.append([step, t, tau, w_inf, E_phys, Z_phys])

    if step % print_interval == 0 or step == 1:
        print(f"{step:7d} | "
              f"t={t:8.3f} | "
              f"E={E_phys:10.6f} | "
              f"Z={Z_phys:10.6f} | "
              f"w_inf={w_inf:10.6f}")

    # Advance clocks
    if mode == "idns":
        t += phi_prime * dt
        tau += dt
    else:
        t += dt
        tau += dt

# ============================================================
# WRAP-UP
# ============================================================
runtime = time.time() - start_time
print("\nSimulation complete.\n")
print(f"Final time t = {t:.3f}")
print(f"Steps = {step}")
print(f"Runtime = {runtime:.2f} s")

# ============================================================
# SAVE CSV
# ============================================================
raw_csv = os.path.join(outdir, f"idns_public_Re{int(Re)}.csv")
with open(raw_csv, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["step", "t", "tau", "w_inf", "E", "Z"])
    writer.writerows(rows)

print(f"Saved CSV → {raw_csv}")
